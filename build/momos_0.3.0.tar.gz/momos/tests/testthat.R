library(testthat)
library(momos)

test_check("momos")
